from win10toast import ToastNotifier
toaster = ToastNotifier()
toaster.show_toast("제목","내용",duration=5)