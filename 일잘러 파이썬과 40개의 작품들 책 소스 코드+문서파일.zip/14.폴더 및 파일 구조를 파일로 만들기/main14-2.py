import seedir as sd

찾을폴더_경로 = r"C:\일잘러 파이썬과 40개의 작품들 코드"

sd.seedir(찾을폴더_경로, style='emoji')