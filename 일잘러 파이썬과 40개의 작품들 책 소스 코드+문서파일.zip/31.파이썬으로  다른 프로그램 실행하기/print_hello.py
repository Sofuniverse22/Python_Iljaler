import time

for i in range(3):
    print("hello")
    time.sleep(1.0)