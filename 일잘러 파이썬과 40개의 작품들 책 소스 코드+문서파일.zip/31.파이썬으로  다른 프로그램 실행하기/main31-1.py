import os

file_path = r'C:\일잘러 파이썬과 40개의 작품들 코드\31.파이썬으로  다른 프로그램 실행하기\test.txt'
os.startfile(file_path)