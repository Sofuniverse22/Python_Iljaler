import pyautogui
import time

while True:
    print(pyautogui.position())
    time.sleep(0.1)